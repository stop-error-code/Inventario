const Sequelize = require('sequelize');

// conexion a base de datos
// TODO pasar a properties
const sequelize = new Sequelize('postgres://appInventario:appInventario@localhost:5432/inventario');

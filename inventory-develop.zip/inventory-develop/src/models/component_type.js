module.exports = (sequelize, DataTypes) => {
    const ComponentType = sequelize.define('componentType', {
    component_type_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'component_type_id'
      },
      component_type_name: {
        type: DataTypes.STRING,
        field: 'component_type_name'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'component_type',underscored: true,timestamps:false });
  
    return ComponentType;
  };
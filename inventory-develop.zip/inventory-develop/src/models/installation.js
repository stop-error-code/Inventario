module.exports = (sequelize, DataTypes) => {
    const Installation = sequelize.define('installation', {
    installation_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'installation_id'
      },
      installation_name: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'installation_description'
      },
      server_id: {
        type: DataTypes.UUID,
        field: 'server_id'
      },
      component_id: {
        type: DataTypes.UUID,
        field: 'component_id'
      },
      enviroment_id: {
        type: DataTypes.UUID,
        field: 'enviroment_id'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'installation',underscored: true,timestamps:false });
  
    return Installation;
  };
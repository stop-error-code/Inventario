

const Sequelize = require('sequelize');
const ApplicationModel = require('./application.js');
const ExpositionModel = require('./exposition.js');
const ServerModel = require('./server.js');
const EnviromentModel = require('./enviroment.js');
const ComponentModel = require('./component.js');
const ComponentTypeModel = require('./component_type.js');
const InstallationModel = require('./installation.js');
const StatusModel = require('./status.js');
const VlanModel = require('./vlan.js');
const SoModel = require('./so.js');

var opts = {
  define: {
    // config para que n genera las tablas en plural
    //  timestamps: true,
      underscored: true,
      underscoredAll: true,
      freezeTableName: true,
      createdAt:'created_at',
      updatedAt:'updated_at'
      
  }
}

const sequelize  = new Sequelize(
  process.env.DATABASE,
  process.env.DATABASE_USER,
  process.env.DATABASE_PASSWORD, {
  host: process.env.DATABASE_HOST,
  dialect: 'postgres'
},{  define: {
  // config para que n genera las tablas en plural
    timestamps: true,
    underscored: true,
    underscoredAll: true,
    freezeTableName: true,
    createdAt:'created_at',
    updatedAt:'updated_at'
} 
})

  /*Object.keys(models).forEach(key => {
    if ('associate' in models[key]) {
      models[key].associate(models);
    }
  });*/
/*Application.hasOne(Exposition,{target:'id'});*/


sequelize.sync({force: (process.env.DATABASE_SYNC=="true")})
  .then(() => {
    console.log(`Database & tables created!`)
  })
  export { sequelize };
  const Application = ApplicationModel(sequelize, Sequelize);
  const Exposition = ExpositionModel(sequelize, Sequelize);
  const Server = ServerModel(sequelize, Sequelize);
  const Enviroment = EnviromentModel(sequelize, Sequelize);
  const Component = ComponentModel(sequelize, Sequelize);
  const ComponentType = ComponentTypeModel(sequelize, Sequelize);
  const Installation = InstallationModel(sequelize, Sequelize);
  const Status = StatusModel(sequelize, Sequelize);
  const Vlan = VlanModel(sequelize, Sequelize);
  const So = SoModel(sequelize, Sequelize);
  
  Application.belongsTo(Exposition, {
    foreignKey: 'id',
    as: 'expositionId'
  });
  
  Application.belongsTo(Status, {
    foreignKey: 'id',
    as: 'statusId'
  });
  
  Server.belongsTo(Vlan, {
    foreignKey: 'id',
    as: 'vlanId'
  });
  
  Server.belongsTo(So, {
    foreignKey: 'id',
    as: 'soId'
  });
  
  Component.belongsTo(Application, {
    foreignKey: 'id',
    as: 'applicationId'
  });
  
  Component.belongsTo(ComponentType, {
    foreignKey: 'id',
    as: 'componentTypeId'
  });
  
  Installation.belongsTo(Enviroment, {
    foreignKey: 'id',
    as: 'enviromentId'
  });
  
  Installation.belongsTo(Component, {
    foreignKey: 'id',
    as: 'componentId'
  });
  
  Installation.belongsTo(Server, {
    foreignKey: 'id',
    as: 'serverId'
  });
  
  module.exports = {
    sequelize,
    Sequelize,
    Application,
    Exposition,
    Server,
    Enviroment,
    Component,
    ComponentType,
    Installation,
    Status,
    Vlan,
    So
  }
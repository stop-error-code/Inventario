const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { Status } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
/*
router.get('/',  (req, res) => {
    Status.findAll().then(function(status){
      var resource=halson({tittle:'statuss',description:'Endpoint que contiene donde esta publicada la app'})
      .addLink('self','/status');
      var embed;
      for(var{  status_id:status_id,
                status_name:status_name,
                created_at:created_at,
                updated_at:updated_at
         } of status)  {
           embed=halson({
            status_id:status_id,
            status_name:status_name,
            created_at:created_at,
            updated_at:updated_at
           })
           .addLink('self','/status/'+status_id)
           resource.addEmbed('statuss',embed);
         }
      res.json(resource);
    }).catch(err=>{
      res.status(500)
      res.json(util.errorHalResponse(null,'/status/',err));
    });
  });*/

router.get('/:status_id', (req, res) => {
    Status.findOne(
        {
            where: {
                status_id: req.params.status_id
            },
            raw: true
        }).then(status => {
            console.log(status);
            res.json(util.toHalsonOneElementAndOneSelfLink(status, '/status/', status.status_id))}
        ).catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/status/', err));
        });

});


router.get('/', (req, res) => {
    Status.findAll().then(status => res.json(util.toHalsonOneElementAndOneSelfLink(status, '/status/', status.status_id))
    ).catch(err => {
        res.status(500)
        res.json(util.errorHalResponse(null, '/status/', err));
    });

});


router.post('/', (req, res) => {
    Status.create({
        status_id: uuidv4(),
        status_name: req.body.status_name,
    }).then(status => {
        var respData = status.get({ plain: true })
        res.json(util.toHalsonOneElementAndOneSelfLink(respData, '/status/', respData.status_id))
    }).
        catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/status/', err));
        });

});


export default router;
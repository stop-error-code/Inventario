import application from './application';
import component from './component';
import server from './server';
import exposition from './exposition';
import component_type from './component_type';
import enviroment from './enviroment';
import installation from './installation';
import so from './so';
import status from './status';
import vlan from './vlan';


console.log("rutas")
export default {
  server,
  component,
  application,
  exposition,
  component_type,
  enviroment,
  installation,
  so,
  status,
  vlan
};
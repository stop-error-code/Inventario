const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const {Server}=require('../models');

router.get('/', (req, res) => {
  Server.findAll().then(server=>res.json(server))
});

router.post('/', (req, res) => {
   Server.create({
     server_id:uuidv4(),
     server_ip_address:req.body.server_ip_address,
     server_hostname:req.body.server_hostname,
     so_id:req.body.so_id,
     server_ip_address:req.body.server_ip_address,
     server_cpu:req.body.server_cpu,
     vlan_id:req.body.vlan_id,
   }).then(server=>res.json(server))
  
});

export default router;
const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { So } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
/*
router.get('/',  (req, res) => {
    So.findAll().then(function(so){
      var resource=halson({tittle:'s',description:'Endpoint que contiene donde esta publicada la app'})
      .addLink('self','/');
      var embed;
      for(var{  _id:_id,
                _name:_name,
                created_at:created_at,
                updated_at:updated_at
         } of )  {
           embed=halson({
            _id:_id,
            _name:_name,
            created_at:created_at,
            updated_at:updated_at
           })
           .addLink('self','/so/'+so_id)
           resource.addEmbed('sos',embed);
         }
      res.json(resource);
    }).catch(err=>{
      res.status(500)
      res.json(util.errorHalResponse(null,'/so/',err));
    });
  });*/

router.get('/:so_id', (req, res) => {
    So.findOne(
        {
            where: {
                so_id: req.params.so_id
            },
            raw: true
        }).then(so => {
            console.log(so);
            res.json(util.toHalsonOneElementAndOneSelfLink(so, '/so/', so.so_id))}
        ).catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/so/', err));
        });

});


router.get('/', (req, res) => {
    So.findAll().then(so => res.json(util.toHalsonOneElementAndOneSelfLink(so, '/so/', so.so_id))
    ).catch(err => {
        res.status(500)
        res.json(util.errorHalResponse(null, '/so/', err));
    });

});


router.post('/', (req, res) => {
    So.create({
        so_id: uuidv4(),
        so_name: req.body.so_name,
    }).then(so => {
        var respData = so.get({ plain: true })
        res.json(util.toHalsonOneElementAndOneSelfLink(respData, '/so/', respData.so_id))
    }).
        catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/so/', err));
        });

});


export default router;
const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { ComponentType } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
/*
router.get('/',  (req, res) => {
    ComponentType.findAll().then(function(component_type){
      var resource=halson({tittle:'component_types',description:'Endpoint que contiene donde esta publicada la app'})
      .addLink('self','/component_type');
      var embed;
      for(var{  component_type_id:component_type_id,
                component_type_name:component_type_name,
                created_at:created_at,
                updated_at:updated_at
         } of component_type)  {
           embed=halson({
            component_type_id:component_type_id,
            component_type_name:component_type_name,
            created_at:created_at,
            updated_at:updated_at
           })
           .addLink('self','/component_type/'+component_type_id)
           resource.addEmbed('component_types',embed);
         }
      res.json(resource);
    }).catch(err=>{
      res.status(500)
      res.json(util.errorHalResponse(null,'/component_type/',err));
    });
  });*/

router.get('/:component_type_id', (req, res) => {
    ComponentType.findOne(
        {
            where: {
                component_type_id: req.params.component_type_id
            },
            raw: true
        }).then(component_type => {
            console.log(component_type);
            res.json(util.toHalsonOneElementAndOneSelfLink(component_type, '/component_type/', component_type.component_type_id))}
        ).catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/component_type/', err));
        });

});


router.get('/', (req, res) => {
    ComponentType.findAll().
    then(component_type => {
        
        component_type.forEach(component_type => {
            util.toHalsonOneElementAndOneSelfLink(component_type, '/component_type/', component_type.component_type_id))
        });
       
        res.json(
    }
        ).catch(err => {
        res.status(500)
        res.json(util.errorHalResponse(null, '/component_type/', err));
    });

});


router.post('/', (req, res) => {
    ComponentType.create({
        component_type_id: uuidv4(),
        component_type_name: req.body.component_type_name,
    }).then(component_type => {
        var respData = component_type.get({ plain: true })
        res.json(util.toHalsonOneElementAndOneSelfLink(respData, '/component_type/', respData.component_type_id))
    }).
        catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/component_type/', err));
        });

});


export default router;
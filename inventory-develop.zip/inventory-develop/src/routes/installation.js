const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const {Installation}= require('../models');
const router = Router();
/*let application = {
    1: {
      applicationId: '2',
      name: 'Newtn',
      applicationStatusId: '1',
    },
    2: {
    applicationId: '1',
    name: 'Autogestion',
    applicationStatusId: '1',
    },
  };*/
router.get('/',  (req, res) => {
  console.log("entro a exposition")
  Installation.findAll().then(installation=>res.json(installation))
});
router.post('/',  (req, res) => {
  const installation = Installation.create({ 
      installation_id: uuidv4(),
      installation_description: req.body.installation_description,
      component_id:req.body.component_id,
      server_id:req.body.server_id,
      enviroment_id:req.body.enviroment_id
      }).then(installation=>res.json(installation))
});

export default router;

var halson = require('halson');
const toHalsonOneElementAndOneSelfLink=(data,endpoint,id) => { 
        
    var resource=halson(data)
    .addLink('self',endpoint +id);
    return resource;
    }
const errorHalResponse=(data,endpoint,message)=>{
    var resource=halson({tittle:process.env.HAL_ERROR_TITTLE,message:message})
    .addLink('self',endpoint);
    return resource;
}
const setHeadersHal=()=>{
 var res=   {}
}
const setStatusCode=()=>{}
exports.setHeadersHal=setHeadersHal;
exports.setStatusCode=setStatusCode;
exports.errorHalResponse=errorHalResponse;
exports.toHalsonOneElementAndOneSelfLink=toHalsonOneElementAndOneSelfLink;


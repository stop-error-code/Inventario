const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const util = require ('./utils/halson');
const {Exposition}= require('../models');
const router = Router();
var halson =require('halson');

router.get('/',  (req, res) => {
  Exposition.findAll().then(function(exposition){
    var resource=halson({tittle:'expositions',description:'Endpoint que contiene donde esta publicada la app'})
    .addLink('self','/exposition');
    var embed;
    for(var{  exposition_id:exposition_id,
              exposition_name:exposition_name,
              created_at:created_at,
              updated_at:updated_at
       } of exposition)  {
         embed=halson({
          exposition_id:exposition_id,
          exposition_name:exposition_name,
          created_at:created_at,
          updated_at:updated_at
         })
         .addLink('self','/exposition/'+exposition_id)
         resource.addEmbed('expositions',embed);
       }
    res.json(resource);
  }).catch(err=>{
    res.status(500)
    res.json(util.errorHalResponse(null,'/exposition/',err));
  });
});
router.get('/:exposition_id',(req,res)=>{
  Exposition.findOne(
    {
      where:{
        exposition_id:req.params.exposition_id
      },
      raw : true 
    }).then(exposition=>res.json(util.toHalsonOneElementAndOneSelfLink(exposition,'/exposition/',exposition.exposition_id))
  ).catch(err=>{
    res.status(500)
    res.json(util.errorHalResponse(null,'/exposition/',err));
  });
});
router.post('/',  (req, res) => {
  const exposition = Exposition.create(
      { 
        exposition_id: uuidv4(),
        exposition_name: req.body.exposition_name
      },
      {raw : true} 
      ).then(exposition=> {
        var respData=exposition.get({plain:true})
        res.json(util.toHalsonOneElementAndOneSelfLink(respData,req.path+'/',respData.exposition_id))}).
      catch(err=>{
          res.status(500)
          res.json(util.errorHalResponse(null,'/exposition/',err));
        });
});
router.delete('/:exposition_id',  (req, res) => {
  Exposition.destroy(
    {
      where:{
        exposition_id:req.params.exposition_id
      },
      
    }).then(exposition=>{
      console.log(exposition)
      res.json(util.toHalsonOneElementAndOneSelfLink(exposition,'/exposition/',exposition.exposition_id))
    }).catch(err=>{
    res.status(500)
    res.json(util.errorHalResponse(null,'/exposition/',err));
  });
});
export default router;
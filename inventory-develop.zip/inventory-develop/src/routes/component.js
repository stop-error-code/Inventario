const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const {Component}=require('../models');

router.get('/:appId/component', (req, res) => {
  Component.findAll({
    where:{
      application_id:req.params.appId}}
      ).then(function(component){
        console.log(component);
        res.json(component)});
});

router.post('/:appId/component/', (req, res) => {
   Component.create({
    component_id:req.body.component_id,
     application_id:req.params.application_id,
     component_name:req.body.component_name,
     component_type_id:req.body.component_type_id
   }).then(component=>res.json(component))
});/*application_id:req.body.applicationId,*/

export default router;
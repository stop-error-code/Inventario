const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { Enviroment } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
/*
router.get('/',  (req, res) => {
    Enviroment.findAll().then(function(exposition){
      var resource=halson({tittle:'expositions',description:'Endpoint que contiene donde esta publicada la app'})
      .addLink('self','/exposition');
      var embed;
      for(var{  exposition_id:exposition_id,
                exposition_name:exposition_name,
                created_at:created_at,
                updated_at:updated_at
         } of exposition)  {
           embed=halson({
            exposition_id:exposition_id,
            exposition_name:exposition_name,
            created_at:created_at,
            updated_at:updated_at
           })
           .addLink('self','/exposition/'+exposition_id)
           resource.addEmbed('expositions',embed);
         }
      res.json(resource);
    }).catch(err=>{
      res.status(500)
      res.json(util.errorHalResponse(null,'/exposition/',err));
    });
  });*/

router.get('/:enviroment_id', (req, res) => {
    Enviroment.findOne(
        {
            where: {
                enviroment_id: req.params.enviroment_id
            },
            raw: true
        }).then(enviroment => {
            console.log(enviroment);
            res.json(util.toHalsonOneElementAndOneSelfLink(enviroment, '/enviroment/', enviroment.enviroment_id))}
        ).catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/enviroment/', err));
        });

});


router.get('/', (req, res) => {
    Enviroment.findAll().then(enviroment => res.json(util.toHalsonOneElementAndOneSelfLink(enviroment, '/enviroment/', exposition.exposition_id))
    ).catch(err => {
        res.status(500)
        res.json(util.errorHalResponse(null, '/enviroment/', err));
    });

});


router.post('/', (req, res) => {
    Enviroment.create({
        enviroment_id: uuidv4(),
        enviroment_name: req.body.enviroment_name,
    }).then(enviroment => {
        var respData = enviroment.get({ plain: true })
        res.json(util.toHalsonOneElementAndOneSelfLink(respData, '/enviroment/', respData.enviroment_id))
    }).
        catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/exposition/', err));
        });

});


export default router;
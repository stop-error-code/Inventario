# Inventario
La idea es basicamente diseñar una aplicacion desde cero, orientada a ser un inventario de Applicaciones.

Trabajando desde cero, con una especificacion, requerimientos funcionales y no funcionales. 
Ademas trabajaramos con el diseño de la applicacion, a priori una aplicacion un front, back y componentes de base de datos.
Orientado a trabajar con rest, mostrandose en un front con angular y una base sql modesta. Todos es

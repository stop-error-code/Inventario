/*
Este modulo esta destinado a guardar funciones utiles*/
var halson_utils=require('./halson.js');
exports.halson_utils=halson_utils;
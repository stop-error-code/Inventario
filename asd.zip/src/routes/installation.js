const uuidv4 = require('uuid/v4');
import { Router } from 'express';
import { toHalsonOneElementAndOneSelfLink } from './utils/halson';
const {Installation}= require('../models');
const router = Router();
var halson = require('halson');
const util = require('./utils/halson')
/*let application = {
    1: {
      applicationId: '2',
      name: 'Newtn',
      applicationStatusId: '1',
    },
    2: {
    applicationId: '1',
    name: 'Autogestion',
    applicationStatusId: '1',
    },
  };*/
router.get('/',  (req, res) => {
  console.log("entro a exposition")
  Installation.findAll().then(function (installation) {
    var resource = halson({ tittle: "installation", description: "Endpoint que contiene el recurso installation" })
      .addLink('self', '/installation');
    console.log(installation);
    for (var {
      installation_id: installation_id,
      installation_description: installation_description,
      created_at: created_at,
      updated_at: updated_at,
      server_id:server_id,
      component_id:component_id,
      enviroment_id:enviroment_id
    } of installation) {
     var embed = toHalson( {
      installation_id: installation_id,
      installation_description: installation_description,
      created_at: created_at,
      updated_at: updated_at,
      server_id:server_id,
      component_id:component_id,
      enviroment_id:enviroment_id
    } )
      resource.addEmbed('installations', embed);
    }
    res.json(resource)
  });
});

router.get('/:installationId',  (req, res) => {
  console.log("entro a instalation ");
  Installation.findOne({ where: {installation_id:req.params.installationId}})
  .then(function(installation){
    res.json(
      toHalson(installation))});
  
});

router.post('/',  (req, res) => {
  const installation = Installation.create({ 
      installation_id: uuidv4(),
      installation_description: req.body.installation_description,
      component_id:req.body.component_id,
      server_id:req.body.server_id,
      enviroment_id:req.body.enviroment_id
      }).then(installation=>res.json(toHalson(installation)))
});
function toHalson(data){
  var {
    installation_id: installation_id,
    installation_description: installation_description,
    created_at: created_at,
    updated_at: updated_at,
    server_id:server_id,
    component_id:component_id,
    enviroment_id:enviroment_id
  } = data;
   var resource= halson({
      installation_id: installation_id,
      installation_description: installation_description,
      created_at: created_at,
      updated_at: updated_at
    })
      .addLink('self', '/installation/'+installation_id)
      .addLink('server', '/server/' + server_id)
      .addLink('enviroment', '/enviroment/' + enviroment_id)
      .addLink('component','/component/'+ component_id);
  
  return resource;
}
export default router;
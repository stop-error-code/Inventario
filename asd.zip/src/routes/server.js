const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { Server } = require('../models');
const util = require('./utils/halson');
var halson = require('halson');



router.get('/', (req, res) => {
  Server.findAll({raw:true}).then(server => {
    var resource = halson({ tittle: "servers", description: "recurso que contiene servidores" })
    .addLink("self", "/servers");
    var embed;
    for (var server_data of server) {
      resource.addEmbed('servers', toHalson(server_data));
    }
    res.json(resource);
  });
});
router.get('/:server_id', (req, res) => {
  Server.findOne(
    {
      where: { server_id: req.params.server_id },
      raw: true
    }).
    then(server => res.json(toHalson(server)))
});

router.post('/', (req, res) => {
  Server.create({
    server_id: uuidv4(),
    server_ip_address: req.body.server_ip_address,
    server_hostname: req.body.server_hostname,
    so_id: req.body.so_id,
    server_memory: req.body.server_memory,
    server_cpu: req.body.server_cpu,
    vlan_id: req.body.vlan_id,
  }).then(server => res.json(server))

});

function toHalson(data) {
  console.log(data);
  var { server_id: server_id, server_ip_address: server_ip_address, server_hostname: server_hostname, so_id: so_id, vlan_id: vlan_id, server_memory: server_memory, server_cpu: server_cpu, created_at: created_at, updated_at: updated_at } = data;
  var resource = halson({
    server_id: server_id,
    server_ip_address: server_ip_address,
    server_hostname: server_hostname,
    server_memory: server_memory,
    server_cpu: server_cpu,
    created_at: created_at,
    updated_at: updated_at
  })
    .addLink('self', '/server/' + server_id);
  if (vlan_id) { resource.addLink('vlan', '/vlan/' + vlan_id) }
  if (so_id) { resource.addLink('so', '/so/' + so_id); }
  console.log(resource);
  return resource;
}

export default router;
const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { Vlan } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
/*
router.get('/',  (req, res) => {
    Vlan.findAll().then(function(vlan){
      var resource=halson({tittle:'vlans',description:'Endpoint que contiene donde esta publicada la app'})
      .addLink('self','/vlan');
      var embed;
      for(var{  vlan_id:vlan_id,
                vlan_name:vlan_name,
                created_at:created_at,
                updated_at:updated_at
         } of vlan)  {
           embed=halson({
            vlan_id:vlan_id,
            vlan_name:vlan_name,
            created_at:created_at,
            updated_at:updated_at
           })
           .addLink('self','/vlan/'+vlan_id)
           resource.addEmbed('vlans',embed);
         }
      res.json(resource);
    }).catch(err=>{
      res.status(500)
      res.json(util.errorHalResponse(null,'/vlan/',err));
    });
  });*/

router.get('/:vlan_id', (req, res) => {
    Vlan.findOne(
        {
            where: {
                vlan_id: req.params.vlan_id
            },
            raw: true
        }).then(vlan => {
            console.log(vlan);
            res.json(util.toHalsonOneElementAndOneSelfLink(vlan, '/vlan/', vlan.vlan_id))}
        ).catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/vlan/', err));
        });

});


router.get('/', (req, res) => {
    Vlan.findAll().then(vlan => res.json(util.toHalsonOneElementAndOneSelfLink(vlan, '/vlan/', vlan.vlan_id))
    ).catch(err => {
        res.status(500)
        res.json(util.errorHalResponse(null, '/vlan/', err));
    });

});


router.post('/', (req, res) => {
    Vlan.create({
        vlan_id: uuidv4(),
        vlan_name: req.body.vlan_name,
        vlan_number:req.body.vlan_number,
        vlan_range:req.body.vlan_range
    }).then(vlan => {
        var respData = vlan.get({ plain: true })
        res.json(util.toHalsonOneElementAndOneSelfLink(respData, '/vlan/', respData.vlan_id))
    }).
        catch(err => {
            res.status(500)
            res.json(util.errorHalResponse(null, '/vlan/', err));
        });

});


export default router;
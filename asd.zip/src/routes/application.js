const uuidv4 = require('uuid/v4');
import { Router, application } from 'express';
const {Application,Exposition}= require('../models');
const router = Router();
var halson =require('halson');
const util = require('./utils/halson');
/*let application = {
    1: {
      applicationId: '2',
      name: 'Newtn',
      applicationStatusId: '1',
    },
    2: {
    applicationId: '1',
    name: 'Autogestion',
    applicationStatusId: '1',
    },
  };*/

  /* retorna las apps por appId, en caso de que el parametro este vacio trae todo*/
router.get('/:appId',  (req, res) => {
  var resource;
    Application.findOne(
      {
        where:{
          application_id:req.params.appId
        },
        raw : true })
      .then(application=> res.json(toHalson(application)))
      .catch(err => {
        console.log(err)
        res.status(500)
        res.json(util.errorHalResponse(null, '/application/', err));
    });
 
});
router.get('/',  (req, res) => {
  Application.findAll().then(function(application)
  {
  var resource=halson({ tittle:"applications", description: "Endpoint que contiene el recurso Aplicaciones"})
  .addLink('self','/application');
  var embed;
  for (var {application_id : application_id,
            application_name:application_name,
          exposition_id:exposition_id,
          application_description : application_description,
          created_at:created_at,
          updated_at:updated_at,
          } of application) {
          embed=halson({
              application_id:application_id,
              application_name:application_name,
              application_description:application_description
            })
            .addLink('self','/application/'+application_id)
            .addLink('exposition','/exposition/'+exposition_id)
            .addLink('components','/application/'+application_id+'/component'); 
            resource.addEmbed('applications',embed);
          }
  res.json(resource);
    }).catch(err => {
      res.status(500)
      res.json(util.errorHalResponse(err, '/application/', err));
  });

});
/*Inserta una nueva app*/
router.post('/',  (req, res) => {
  console.log(req.body.application_description);
  const application = Application.create({ 
    application_id: uuidv4(),
    application_name: req.body.application_name,
    application_description: req.body.application_description,
    exposition_id:req.body.exposition_id,
    status_id:req.body.status_id,

      }).then(application=>res.json(toHalson(application)))
.catch(err => {
  res.status(500)
  res.json(util.errorHalResponse(null, '/application/', err));
});
});
function toHalson(data){
  
    console.log(data);
    var {application_id : application_id,application_name:application_name,exposition_id:exposition_id,application_description : application_description,created_at:created_at,updated_at:updated_at,status_id:status_id}=data;
    var resource=halson({
      application_id:application_id,
      application_name:application_name,
      application_description:application_description
    })
    .addLink('self','/application/'+application_id)
    .addLink('exposition','/exposition/'+exposition_id)
    .addLink('status','/status/'+status_id)
    .addLink('components','/application/'+application_id+'/component'); 
    console.log(resource);
return resource;
}

export default router; 
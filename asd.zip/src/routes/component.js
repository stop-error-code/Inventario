const uuidv4 = require('uuid/v4');
import { Router } from 'express';
const router = Router();
const { Component } = require('../models');
var halson = require('halson');
const util = require('./utils/halson');
router.get('/:appId/component', (req, res) => {
  Component.findAll({
    where: {
      application_id: req.params.appId
    }
  }
  ).then(function (component) {
    var resource = halson({ tittle: "components", description: "Endpoint que contiene el recurso Component" })
      .addLink('self', '/application/' + req.params.appId + '/component');
    console.log(component);
    for (var { application_id: application_id,
      component_description: component_description,
      component_id: component_id,
      component_type_id: component_type_id,
      created_at: created_at,
      updated_at: updated_at, } of component) {
      embed=toHalson({ application_id: application_id,
        component_description: component_description,
        component_id: component_id,
        component_type_id: component_type_id,
        created_at: created_at,
        updated_at: updated_at, });
      resource.addEmbed('components', embed);
    }
    res.json(resource);
  });
});

router.get('/:appId/component/:componentId', (req, res) => {
  Component.findOne({
    where: {
      application_id: req.params.appId,
      component_id:req.params.componentId
    }
  }
  ).then(function (component) {
    console.log(component);
    res.json(toHalson(component))
  });
});

router.post('/:applicationId/component/', (req, res) => {
  Component.create({
    component_id: uuidv4(),
    application_id: req.params.applicationId,
    component_description: req.body.component_description,
    component_type_id: req.body.component_type_id
  }).then(component => res.json(toHalson(component)))
});/*application_id:req.body.applicationId,*/

function toHalson(data){
  var { application_id: application_id,
    component_description: component_description,
    component_id: component_id,
    component_type_id: component_type_id,
    created_at: created_at,
    updated_at: updated_at } = data ;
   var  resource = halson({
      component_id: component_id,
      component_description: component_description,
      created_at: created_at,
      updated_at: updated_at
    })
      .addLink('self', '/application/' + application_id + '/component/' + component_id)
      .addLink('application', '/application/' + application_id)
      .addLink('component_type', '/component_type/' + component_type_id);
  return resource;


}
export default router;
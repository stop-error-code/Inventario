module.exports = (sequelize, DataTypes) => {
    const Application = sequelize.define('application', {
      application_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'application_id'
      },
      application_name: {
        type: DataTypes.STRING,
        field: 'application_name'
      },
      application_description: {
        type: DataTypes.STRING,
        field: 'application_description'
      },
      exposition_id: {
        type: DataTypes.UUID,
        field: 'exposition_id',
        allowNull: false,
      },
      status_id: {
        type: DataTypes.UUID,
        field: 'status_id',
        allowNull: false,
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'application',underscored: true,timestamps:false});
  
    return Application;
  };
module.exports = (sequelize, DataTypes) => {
    const Status = sequelize.define('status', {
        status_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'status_id'
      },
      status_name: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'status_description'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'status',underscored: true,timestamps:false });
  
    return Status;
  };
module.exports = (sequelize, DataTypes) => {
    const So = sequelize.define('so', {
    so_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'so_id'
      },
      so_name: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'so_description'
      },
      so_end_of_support: {
        type: DataTypes.DATEONLY,
        field: 'so_end_of_support'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'so',underscored: true,timestamps:false });
  
    return So;
  };
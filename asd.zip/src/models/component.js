module.exports = (sequelize, DataTypes) => {
    const Component = sequelize.define('component', {
    component_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'component_id'
      },
    component_description: {
        type: DataTypes.STRING,
        field: 'component_description'
      },
    component_type_id: {
        type: DataTypes.UUID,
        field: 'component_type_id'
      },
    application_id: {
        type: DataTypes.UUID,
        field: 'application_id'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'component' ,underscored: true,timestamps:false});
  
    return Component;
  };
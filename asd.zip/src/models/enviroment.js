module.exports = (sequelize, DataTypes) => {
    const Enviroment = sequelize.define('enviroment', {
    enviroment_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'enviroment_id'
      },
    enviroment_name: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'enviroment_description'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'enviroment',underscored: true,timestamps:false });
  
    return Enviroment;
  };
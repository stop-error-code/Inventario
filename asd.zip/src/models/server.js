module.exports = (sequelize, DataTypes) => {
    const Server = sequelize.define('server', {
    server_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'server_id'
      },
      server_hostname: {
        type: DataTypes.STRING,
        field: 'server_hostname'
      },
      so_id: {
        type: DataTypes.BLOB,
        field: 'so_id'
      },
      server_ip_address: {
        type: DataTypes.STRING,
        field: 'server_ip_address'
      },
      server_cpu: {
        type: DataTypes.STRING,
        field: 'server_cpu'
      },
      server_memory: {
        type: DataTypes.STRING,
        field: 'server_memory'
      },
      vlan_id: {
        type: DataTypes.UUID,
        field: 'vlan_id'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'server' ,underscored: true,timestamps:false});
  
    return Server;
  };
module.exports = (sequelize, DataTypes) => {
    const Vlan = sequelize.define('vlan', {
        vlan_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'vlan_id'
      },
      vlan_name: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'vlan_name'
      },
      vlan_number: {
        type: DataTypes.STRING,
        field: 'vlan_number'
      },
      vlan_range: {
        type: DataTypes.STRING,
        field: 'vlan_range'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'vlan',underscored: true,timestamps:false });
  
    return Vlan;
  };
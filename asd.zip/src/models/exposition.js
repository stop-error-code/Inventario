module.exports = (sequelize, DataTypes) => {
    const Exposition = sequelize.define('exposition', {
    exposition_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        allowNull: false,
        unique: true,
        field: 'exposition_id'
      },
      exposition_name: {
        type: DataTypes.STRING,
        field: 'exposition_description'
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, { tableName: 'exposition',underscored: true,timestamps:false});
  
    return Exposition;
  };